#!/bin/bash
while true
do
./wildrig --cuda-launch=1024x256 --send-stale --url=bbr.luckypool.io:5577 --user=WALLET --pass=IFNEEDED --scratchpad-file=scratchpad.bin --scratchpad-url=http://eu-bbr.luckypool.io/scratchpad.bin
sleep 5
done
